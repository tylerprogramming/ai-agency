# Calendar Credentials

Place your Google Calendar API credentials here:

1. Download your OAuth 2.0 credentials from Google Cloud Console
2. Rename the file to `client_secrets.json`
3. Place it in this directory

The file should be named exactly: `client_secrets.json`

⚠️ **Never commit actual credentials to version control!**
