import os
import json
from datetime import datetime, timedelta
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

SCOPES = ['https://www.googleapis.com/auth/calendar']

def authenticate_google_calendar():
    creds = None
    
    if os.path.exists('calendar_credentials/calendar_token.json'):
        creds = Credentials.from_authorized_user_file('calendar_credentials/calendar_token.json', SCOPES)
    
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                'calendar_credentials/client_secrets.json', SCOPES)
            creds = flow.run_local_server(port=8080)
        
        with open('calendar_credentials/calendar_token.json', 'w') as token:
            token.write(creds.to_json())
    
    return creds

def get_current_month_events():
    try:
        creds = authenticate_google_calendar()
        service = build('calendar', 'v3', credentials=creds)
        
        now = datetime.now()
        start_of_month = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        
        if now.month == 12:
            end_of_month = start_of_month.replace(year=now.year + 1, month=1) - timedelta(seconds=1)
        else:
            end_of_month = start_of_month.replace(month=now.month + 1) - timedelta(seconds=1)
        
        events_result = service.events().list(
            calendarId='primary',
            timeMin=start_of_month.isoformat() + 'Z',
            timeMax=end_of_month.isoformat() + 'Z',
            maxResults=2500,
            singleEvents=True,
            orderBy='startTime'
        ).execute()
        
        events = events_result.get('items', [])
        
        if not events:
            print('No events found for this month.')
            return []
        
        print(f'Found {len(events)} events for {now.strftime("%B %Y")}:')
        
        event_list = []
        for event in events:
            start = event['start'].get('dateTime', event['start'].get('date'))
            end = event['end'].get('dateTime', event['end'].get('date'))
            
            event_info = {
                'summary': event.get('summary', 'No Title'),
                'start': start,
                'end': end,
                'description': event.get('description', ''),
                'location': event.get('location', ''),
                'attendees': [attendee.get('email') for attendee in event.get('attendees', [])],
                'id': event.get('id'),
                'html_link': event.get('htmlLink')
            }
            
            event_list.append(event_info)
            
            print(f"- {event_info['summary']}: {start}")
        
        return event_list
        
    except HttpError as error:
        print(f'An error occurred: {error}')
        return []

if __name__ == '__main__':
    events = get_current_month_events()
    
    print(f"\nTotal events retrieved: {len(events)}")
    
    if events:
        with open('current_month_events.json', 'w') as f:
            json.dump(events, f, indent=2, default=str)
        print("Events saved to 'current_month_events.json'")